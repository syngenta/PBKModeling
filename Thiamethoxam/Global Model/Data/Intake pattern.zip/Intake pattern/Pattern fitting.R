
library(ggplot2)

rm(list = ls())

df <- read.csv("C:/Users/s1036120/OneDrive - Syngenta/HTTK/Bird/Intake pattern/Pattern.csv")
plot(df$Time, df$g, pch=19, xlab='x', ylab='y')

fit2 <- lm(g~poly(Time,5,raw=TRUE), data=df)

#create a scatterplot of x vs. y
plot(df$Time, df$g, pch=19, xlab='x', ylab='y')

#define x-axis values
x_axis <- seq(1, 22, length=15)
lines(x_axis, predict(fit2, data.frame(Time=x_axis)), col='red')
